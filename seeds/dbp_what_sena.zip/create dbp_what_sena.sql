-- ! ================================================================================================================================================
-- !                                                        SQL PARA INSERTAR DATOS
-- ! ================================================================================================================================================
-- @author Brayan Josue Yanez Gonzalez (30 Septiembre de 2024)
-- @lastModified Brayan Josue Yanez Gonzalez (30 de Septiembre de 2024)
-- @version 1.0.0
-- seeds/data_tables.sql

CREATE DATABASE IF NOT EXISTS dbp_what_sena;


